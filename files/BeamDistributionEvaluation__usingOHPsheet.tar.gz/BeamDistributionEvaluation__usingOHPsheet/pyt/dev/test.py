import cv2
import numpy as np

def extract_rectangle_laplacian(
        inpFile="img/ohp-01_20251112-145755.tif",
        lap_ksize=3,
        zero_ratio=0.10,        # max-min の10%を zero-cross しきい値にする
        hough_thr=80,
        min_line_len=150,
        max_line_gap=20
    ):

    # --- load & normalize --- #
    img16 = cv2.imread(inpFile, cv2.IMREAD_UNCHANGED)
    img8  = cv2.normalize(img16, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    # --- light smoothing --- #
    blur = cv2.GaussianBlur(img8, (3,3), 0.8)

    # --- Laplacian --- #
    lap = cv2.Laplacian(blur, cv2.CV_32F, ksize=lap_ksize)

    # --- auto zero threshold --- #
    Lmin, Lmax = float(lap.min()), float(lap.max())
    zthr = (Lmax - Lmin) * zero_ratio

    # --- Zero crossing detection --- #
    zx = np.zeros_like(img8)
    h, w = lap.shape

    for y in range(1, h-1):
        for x in range(1, w-1):
            p = lap[y,x]
            patch = lap[y-1:y+2, x-1:x+2]
            # 符号が変化していて、強度も十分(patch差がzthr以上)
            if (p > zthr and np.any(patch < -zthr)) or \
               (p < -zthr and np.any(patch >  zthr)):
                zx[y,x] = 255

    # --- HoughLinesP for straight edges --- #
    lines = cv2.HoughLinesP(
        zx, rho=1, theta=np.pi/180,
        threshold=hough_thr,
        minLineLength=min_line_len,
        maxLineGap=max_line_gap
    )

    if lines is None:
        print("No lines detected (Hough).")
        cv2.imwrite("lap_zero.png", zx)
        return

    # --- collect line segments --- #
    segments = []
    for l in lines:
        x1,y1,x2,y2 = l[0]
        segments.append(((x1,y1),(x2,y2)))

    # --- find bounding box from all line points --- #
    xs = []
    ys = []
    for (x1,y1),(x2,y2) in segments:
        xs.extend([x1,x2])
        ys.extend([y1,y2])

    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)

    print("Detected rectangle:", xmin, ymin, xmax-xmin, ymax-ymin)

    # --- visualization --- #
    vis = cv2.cvtColor(img8, cv2.COLOR_GRAY2BGR)
    for (x1,y1),(x2,y2) in segments:
        cv2.line(vis, (x1,y1), (x2,y2), (0,255,0), 2)
    cv2.rectangle(vis, (xmin,ymin), (xmax,ymax), (0,0,255), 2)

    cv2.imwrite("lap_zero.png", zx)
    cv2.imwrite("lap_hough_rect.png", vis)

    # --- crop --- #
    cropped = img16[ymin:ymax, xmin:xmax]
    cv2.imwrite("crop_laplacian.png", cropped)


# ========================================================= #
# ===   Execution of Pragram                            === #
# ========================================================= #

if ( __name__=="__main__" ):
    extract_rectangle_laplacian()
