import cv2
import numpy as np

def extract__OHPfilmRegion(
        inpFile="img/ohp-01_20251112-145755.tif",
        grad_thresh = 20,      # 勾配しきい値（ここが “目で見える閾値”）
        MIN_AREA    = 1000,
    ):

    # --- [1] load 16bit tiff & normalize to 8bit --- #
    img16 = cv2.imread(inpFile, cv2.IMREAD_UNCHANGED)
    img8  = cv2.normalize(img16, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    # --- [2] 軽くぼかす（ノイズ抑制。エッジ位置はほぼ動かさない） --- #
    blur = cv2.GaussianBlur(img8, (5,5), 1.0)

    # --- [3] Sobel で勾配（Laplacian でもOK） --- #
    gx = cv2.Sobel(blur, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(blur, cv2.CV_32F, 0, 1, ksize=3)
    mag = cv2.magnitude(gx, gy)

    # --- [4] 勾配強度にしきい値をかけて、急峻な部分だけ二値化 --- #
    mag_norm = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
    mag_u8   = mag_norm.astype(np.uint8)
    _, edges = cv2.threshold(mag_u8, grad_thresh, 255, cv2.THRESH_BINARY)

    # --- [5] 最大輪郭を矩形化 --- #
    contours,_ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        print("no contour detected")
        return

    contours = [c for c in contours if cv2.contourArea(c) > MIN_AREA]
    if not contours:
        print("no large contour detected")
        return

    cnt = max(contours, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(cnt)
    print("Detected ROI:", x, y, w, h)

    # --- [6] 可視化 & 切り出し --- #
    vis = cv2.cvtColor(img8, cv2.COLOR_GRAY2BGR)
    cv2.rectangle(vis, (x, y), (x+w, y+h), (0,255,0), 2)
    cv2.imwrite("debug_grad_edges.png", edges)
    cv2.imwrite("detected_roi_grad.png", vis)

    cropped = img16[y:y+h, x:x+w]
    cv2.imwrite("cropped_grad.tif", cropped)

# ========================================================= #
# ===   Execution of Pragram                            === #
# ========================================================= #

if ( __name__=="__main__" ):
    extract__OHPfilmRegion()
