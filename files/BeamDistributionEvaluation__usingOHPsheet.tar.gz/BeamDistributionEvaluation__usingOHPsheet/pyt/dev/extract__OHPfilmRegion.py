import os, sys, cv2
import numpy as np
import matplotlib.pyplot as plt

def extract__OHPfilmRegion( inpFile="img/ohp-01_20251112-145755.tif", \
                            threshold=8.0, canny_detection=True, MIN_AREA=1000 ):


    
    
    # ------------------------------------------------- #
    # --- [1] load .tiff figure                     --- #
    # ------------------------------------------------- #
    # cv2.IMREAD_UNCHANGED = -1 :: 16 bit .tiff    []
    img16      = cv2.imread( inpFile, cv2.IMREAD_UNCHANGED )
    img8       = cv2.normalize( img16, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    # ------------------------------------------------- #
    # --- [2] extract above threashold              --- #
    # ------------------------------------------------- #
    _,binary   = cv2.threshold( img8, threshold, 255, cv2.THRESH_BINARY )
    cv2.imwrite( "threashold.png", binary )
    
    # if ( canny_detection ):
    #     # blur       = cv2.GaussianBlur( img8, (9,9), 2 )
    #     cv2.imwrite( "img8.png", img8 )
    #     sys.exit()
    #     edges      = cv2.Canny( blur, 100, 200 )
    #     cv2.imshow( "temp.png", edges )
    #     contours,_ = cv2.findContours( edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE )
    #     large      = [ c for c in contours if cv2.contourArea(c) > MIN_AREA ]
    #     print( len( large ) )
    # else:
    #     contours,_ = cv2.findContours( binary8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE )
    # cnt        = max( contours, key=cv2.contourArea )
    # x,y, w,h   = cv2.boundingRect( cnt )
    # print("Detected ROI:", x, y, w, h)

    # img_       = cv2.normalize( img, None, 0, 255,
    #                             cv2.NORM_MINMAX ).astype( np.uint8 )
    # img_       = cv2.cvtColor( img_, cv2.COLOR_GRAY2BGR )
    # img_       = cv2.rectangle( img_, (x,y), (x+w,y+h),
    #                             color=(0,255,0), thickness=5 )
    # cv2.imwrite( "detected_roi.png", img_ )
    # cropped    = img[ y:y+h, x:x+w ]
    # cv2.imwrite( "png/cropped.png", cropped )

    
# ========================================================= #
# ===   Execution of Pragram                            === #
# ========================================================= #

if ( __name__=="__main__" ):
    extract__OHPfilmRegion()
