import os, sys, cv2
import numpy as np
import matplotlib.pyplot as plt


def detect__OHPsheetEdge( inpFile=None ):

    xfilmsize_px  = 300
    yfilmsize_px  = 300

    # ------------------------------------------------- #
    # --- [1] load images                           --- #
    # ------------------------------------------------- #
    img16         = cv2.imread( inpFile, cv2.IMREAD_UNCHANGED )
    blur          = cv2.GaussianBlur( img16, (11,11), 5 )

    # ------------------------------------------------- #
    # --- [2] to 1D profile                         --- #
    # ------------------------------------------------- #
    ypeak, xpeak  = np.unravel_index( np.argmax( blur ), shape=blur.shape )
    xrange_tight  = [ int(xpeak-xfilmsize_px/5), int(xpeak+xfilmsize_px/5) ]
    yrange_tight  = [ int(ypeak-yfilmsize_px/5), int(ypeak+yfilmsize_px/5) ]
    xrange_broad  = [ int(xpeak-xfilmsize_px*2), int(xpeak+xfilmsize_px*2) ]
    yrange_broad  = [ int(ypeak-yfilmsize_px*2), int(ypeak+yfilmsize_px*2) ]
    xprofiles     = blur[ yrange_tight[0]:yrange_tight[1], xrange_broad[0]:xrange_broad[1] ]
    yprofiles     = blur[ yrange_broad[0]:yrange_broad[1], xrange_tight[0]:xrange_tight[1] ]


    # ------------------------------------------------- #
    # --- [3] search max. derivative point          --- #
    # ------------------------------------------------- #
    xstack = []
    for ik in range(xprofiles.shape[0]):
        prof      = xprofiles[ik,:] / ( np.max( xprofiles[ik,:] ) - np.min( xprofiles[ik,:] ) )
        diff      = np.diff( prof )
        xL        = int( np.argmax( diff ) + xrange_broad[0] )
        xR        = int( np.argmin( diff ) + xrange_broad[0] )
        xstack   += [ [ xL, xR ] ]
    ystack = []
    for ik in range(yprofiles.shape[1]):
        prof      = yprofiles[:,ik] / ( np.max( yprofiles[:,ik] ) - np.min( yprofiles[:,ik] ) )
        diff      = np.diff( prof )
        yL        = int( np.argmax( diff ) + yrange_broad[0] )
        yR        = int( np.argmin( diff ) + yrange_broad[0] )
        ystack   += [ [ yL, yR ] ]

    # ------------------------------------------------- #
    # --- [4] edge/center point under ristriction   --- #
    # ------------------------------------------------- #
    xedges  = np.median( np.array( xstack ), axis=0 )
    yedges  = np.median( np.array( ystack ), axis=0 )
    xcenter = round( np.average( xedges ) )
    ycenter = round( np.average( yedges ) )
    xLCR    = [ int(xcenter-xfilmsize_px/2), int(xcenter), int(xcenter+xfilmsize_px/2) ]
    yBCT    = [ int(ycenter-yfilmsize_px/2), int(ycenter), int(ycenter+yfilmsize_px/2) ]
    img8    = cv2.normalize( img16, None, 0, 255, cv2.NORM_MINMAX).astype( np.uint8 )
    img     = cv2.cvtColor( img8, cv2.COLOR_GRAY2BGR )
    img     = cv2.rectangle( img, (xLCR[0],yBCT[0]), (xLCR[2],yBCT[2]), \
                             (255,0,0), 2 )
    img     = cv2.line( img, (xLCR[1],yBCT[0]), (xLCR[1],yBCT[2]), (255,0,0), 2 )
    img     = cv2.line( img, (xLCR[0],yBCT[1]), (xLCR[2],yBCT[1]), (255,0,0), 2 )
    cropped = img16[ yBCT[0]:yBCT[2], xLCR[0]:xLCR[2] ]
    
    # ------------------------------------------------- #
    # --- [5] save and return                       --- #
    # ------------------------------------------------- #
    if ( checkFile is not None ):
        cv2.imwrite( checkFile, img )
    if ( cropFile  is not None ):
        cv2.imwrite( cropFile, cropped )
    ret = { "xLeft"  :xLCR[0], "xCenter":xLCR[1], "xRight":xLCR[2],
            "yBottom":yBCT[0], "yCenter":yBCT[1], "yTop"  :yBCT[2],
            "image"  :img    , "cropped":cropped }
    return( ret )

# ========================================================= #
# ===   Execution of Pragram                            === #
# ========================================================= #

if ( __name__=="__main__" ):
    inpFile = "img/ohp-01_20251112-145755.tif"
    ret     = detect__OHPsheetEdge( inpFile=inpFile, \
                                    checkFile="png/check.png",
                                    croppedFile="png/cropped.png" )
