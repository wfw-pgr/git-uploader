import os, sys, cv2
import numpy as np
import matplotlib.pyplot as plt

# ========================================================= #
# ===  evaluate beam on OHP sheet                       === #
# ========================================================= #

def evaluate__beamOnOHPSheet( inpFile=None ):

    # ------------------------------------------------- #
    # --- [1] arguments                             --- #
    # ------------------------------------------------- #
    img = cv2.imread( inpFile )

    # ------------------------------------------------- #
    # --- [2] pre-process                           --- #
    # ------------------------------------------------- #
    gray    = cv2.cvtColor( img, cv2.COLOR_BGR2GRAY )
    blur    = cv2.GaussianBlur( gray, ( 5, 5 ), 0 )
    plt.figure()
    plt.imshow( blur )
    plt.show()
    edges   = cv2.Canny( blur, 100, 200 )
    print( edges )
    plt.figure()
    plt.imshow( edges )
    plt.show()
    sys.exit()
    cnts,_  = cv2.findContours( edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE )
    print( cnts )
    cnt     = max( cnts, key=cv2.contourArea )
    rect    = cv2.minAreaRect( cnt )
    box     = cv2.boxPoints( rect )
    box     = np.int0(box)
    print( box )
    
    # # 射影変換して切り抜く（順序付け）
    # w       = int(rect[1][0])
    # h       = int(rect[1][1])
    
    # src_pts = box.astype("float32")
    # dst_pts = np.array([[ 0, h-1],
    #                     [ 0, 0],
    #                     [ w-1, 0],
    #                     [ w-1, h-1]], dtype="float32")
    
    # M       = cv2.getPerspectiveTransform(src_pts, dst_pts)
    # warp    = cv2.warpPerspective(img, M, (w, h))

    # # 保存
    # cv2.imwrite("cropped.png", warp)

    

# ========================================================= #
# ===   Execution of Pragram                            === #
# ========================================================= #

if ( __name__=="__main__" ):

    inpFile = "img/ohp-01_20251112-145755.tif"
    evaluate__beamOnOHPSheet( inpFile=inpFile )
    

