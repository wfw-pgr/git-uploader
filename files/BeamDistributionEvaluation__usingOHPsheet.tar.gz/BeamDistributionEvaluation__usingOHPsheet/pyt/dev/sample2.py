import os, sys, cv2
import numpy as np
import matplotlib.pyplot as plt

def extract__OHPfilmRegion():

    nouse_x1   = 50
    nouse_x2   = 100
    nouse_y1   = 50
    nouse_y2   = 100

    # ------------------------------------------------- #
    # --- [1] load .tiff figure                     --- #
    # ------------------------------------------------- #
    # cv2.IMREAD_UNCHANGED = -1 :: 16 bit .tiff    [o]
    img        = cv2.imread( "img/ohp-01_20251112-145755.tif", cv2.IMREAD_UNCHANGED )
    img        = cv2.normalize( img, None, 0, 65536, cv2.NORM_MINMAX )
    threashold = np.average( img[nouse_x1:nouse_x2,nouse_y1:nouse_y2] )

    # ------------------------------------------------- #
    # --- [2] extract above threashold              --- #
    # ------------------------------------------------- #
    # --- High-intensity thresholding ---
    # background is < 500, signal is > 5000
    ret,binary = cv2.threshold( img, threashold, 255, cv2.THRESH_BINARY )
    print( ret, binary )
    
    # --- Extract largest connected region ---
    contours, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnt = max(contours, key=cv2.contourArea)
    
    # --- Bounding rectangle ---
    x, y, w, h = cv2.boundingRect(cnt)
    print("Detected ROI:", x, y, w, h)
    
    # --- Crop ---
    crop = gray[y:y+h, x:x+w]
    
    # --- Save ---
    cv2.imwrite("cropped.tif", crop)

    
# ========================================================= #
# ===   Execution of Pragram                            === #
# ========================================================= #

if ( __name__=="__main__" ):
    extract__OHPfilmRegion()
