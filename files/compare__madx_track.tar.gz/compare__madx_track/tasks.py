import os, sys, glob
import invoke
import cpymad.madx
import pandas as pd
import nk_toolkit.madx.load__tfs          as ltf
import nk_toolkit.madx.plotly__beamline   as pbl
import pyt.twiss__postProcess   as tpp
import pyt.twiss__fromTrackLine as ttl
import pyt.validate__track_madx as vtm
import pyt.plot__Ek as pek
import pyt.compare as com

# ========================================================= #
# ===  madx command                                     === #
# ========================================================= #
@invoke.task( help={ 'file': '.madx file == input file.'} )
def madx( c, file="main.madx", wrkdir="madx/" ):
    """execute madx calculation."""
    os.chdir( wrkdir )
    
    # ------------------------------------------------- #
    # --- [1] file check                            --- #
    # ------------------------------------------------- #
    if not( os.path.exists(file) ):
        filelist = glob.glob( "./*.madx" )
        if ( len(filelist) == 1 ):
            file = filelist[0]
            print( f" following .madx file will be used... :: {file}" )
        else:
            sys.exit(" cannot find input file :: {}".format( file ))
    else:
        print( f"\n --- input : {file} --- \n" )
    # ------------------------------------------------- #
    # --- [2] execute madx                          --- #
    # ------------------------------------------------- #
    m = cpymad.madx.Madx()
    try:
        m.call( file )
        print( "\n --- End of Execution --- \n" )
    except:
        print( "Error" )
    os.chdir( "../" )
    return()


# ========================================================= #
# ===  data compress                                    === #
# ========================================================= #
@invoke.task
def compress( c ):
    """compress .tfs data"""
    # ------------------------------------------------- #
    # --- [1] file search                           --- #
    # ------------------------------------------------- #
    files1 = glob.glob( "madx/out/*.tfs"    )
    files2 = glob.glob( "madx/out/*.tfsone" )
    files  = files1 + files2
    # ------------------------------------------------- #
    # --- [2] compress                              --- #
    # ------------------------------------------------- #
    for ifile in files:
        contents = ltf.load__tfs( tfsFile=ifile )
        ofile    = ( ifile.replace( ".tfsone", ".h5" ) ).replace( ".tfs", ".h5" )
        contents["df"].to_hdf( ofile, key="data" )
        print( " output -- {}".format( ofile ) )
    return()

# ========================================================= #
# ===  post command                                     === #
# ========================================================= #
@invoke.task(pre=[compress])
def post( c, surveyFile="madx/out/survey.tfs"  , twissFile="madx/out/twiss.tfs", \
          tracklineFile="madx/out/trackline.h5", twissOutput="dat/ptc_twiss.h5", \
          html="dat/plot.html" ):
    """post analysis, like plot."""
    # ------------------------------------------------- #
    # --- [1] file check                            --- #
    # ------------------------------------------------- #
    if not( os.path.exists(surveyFile) ):
        sys.exit(" cannot find survey file :: {:<30}".format( surveyFile ) )
    else:
        print( f" --- surveyFile : {surveyFile}" )
    if not( os.path.exists(twissFile) ):
        sys.exit(" cannot find survey file :: {:<30}".format( twissFile ) )
    else:
        print( f" ---  twissFile : {twissFile}" )
    # ------------------------------------------------- #
    # --- [2] execute post analysis                 --- #
    # ------------------------------------------------- #
    #  -- ptc-twiss -> csv -- #
    survey     = ltf.load__tfs( tfsFile=surveyFile )
    twiss      = ltf.load__tfs( tfsFile= twissFile )
    csvFile    = twissFile.replace( ".tfs", ".h5"  )
    twiss      = tpp.twiss__postProcess( twiss=twiss, outFile=twissOutput )
    #  -- trackline -> twiss parameters -- #
    df         = pd.read_hdf( tracklineFile )
    trackline  = ttl.twiss__fromTrackline( df=df )
    trackline.to_hdf( "dat/twiss__fromTrackLine.h5", key="data" )
    #  -- plotly -- #
    pbl.plotly__beamline( survey=survey, twiss=twiss, html=html )
    pek.plot__Ek()
    vtm.validate__track_madx()
    com.compare()
    return()

    
# ========================================================= #
# ===  clean command                                    === #
# ========================================================= #
@invoke.task
def clean(c):
    """clean madx outputs."""    
    extensions = [".twiss", ".track", ".table", ".log", ".out"]
    deleted    = 0
    for file in os.listdir("."):
        if any( file.endswith( ext ) for ext in extensions ):
            os.remove(file)
            deleted += 1
    print(f" --- delte : {deleted} files --- " )
    return()


# ========================================================= #
# ===  all command                                      === #
# ========================================================= #
@invoke.task(pre=[clean, madx, compress, post])
def all(c):
    """all command"""    
    print( "  --- clean, madx, plot command is done --- " )
