import os, sys, json5
import numpy          as np
import pandas         as pd

# ========================================================= #
# ===  translate__track2madx.py                         === #
# ========================================================= #

def translate__track2madx( seq_tag  = "MidBeta", seqFile="madx/1a-deuteron.seq", \
                           obsFile  = "madx/ptc_observe.madx", \
                           trackFile= "track/sclinac.dat", energyFile="track/beam.out" ):
    
    cm       = 1.e-2
    MeV      = 1.e+6
    gauss    = 1.e-4           # [T]
    
    # ------------------------------------------------- #
    # --- [1] read track file                       --- #
    # ------------------------------------------------- #
    with open( trackFile , "r" ) as f:
        lines  = f.readlines()
    with open( energyFile, "r" ) as f:
        energy = pd.read_csv( f, header=0, sep=r"\s+" )
    inpFile = "dat/parameters.json"
    with open( inpFile, "r" ) as f:
        params = json5.load( f )
    E0       = params["mass/u"] * params["umass"]
    n_bessel = params["translate.n_bessel"]
    
    # ------------------------------------------------- #
    # --- [2] analyze each line                     --- #
    # ------------------------------------------------- #
    seq, at      = [], 0.0
    qmnum, rfnum = 0, 0
    drnum, elnum = 0, 0
    for ik,line in enumerate(lines):
        words = ( line.split() )
        if ( not( len( words ) == 0 ) ):
            elnum += 1
            if   ( words[1]  == "quad" ):
                qmnum += 1
                Ek     = energy["Energy[MeV/u]"][elnum] * params["Nu"]      #  -- [MeV]
                # Ek     = energy["Energy[MeV/u]"][elnum]                     #  -- [MeV]
                # Ek     = 40.0 # -- [MeV]
                pc     = np.sqrt( Ek**2 + 2.0*Ek*E0 )                       #  -- [MeV] = c*p
                BRho   = pc * MeV / params["cv"]          #  -- [Tm]  = p/q = pc*qe/(cv*qe)
                gradB  = ( float(words[2])*gauss ) / ( float(words[5])*cm ) #  -- [T/m]
                K1     = gradB / BRho                                       #  -- [1/m2]
                L      = float(words[4]) * cm
                seq   += [ { "type":"quadrupole", "tag": f"qm{qmnum}",
                             "K1":K1, "L":L, "at":at, "Ek":Ek } ]
                at    += L
            elif ( words[1]  == "drift" ):
                drnum += 1
                L      = float(words[2]) * cm
                seq   += [ { "type":"drift", "tag":f"dr{drnum}", "L":L, "at":at } ]
                at    += L
            elif ( words[1]  == "rfgap" ):
                rfnum   += 1
                L        = 0.0 * cm
                volt     = float(words[2])  # volt : (MV)
                lag      = params["translate.lagSign"] * float(words[3]) / 360.0
                harmon   =   int(words[4])
                freq     = params["freq_0"] * harmon # -- harmon is for ring. see MAD-X's manual.
                n_bessel = n_bessel
                harmon   = 1
                seq     += [ { "type":"RFcavity", "tag":f"rf{rfnum}", "L":L, "volt":volt, \
                               "lag":lag, "freq":freq, "harmon":harmon, "n_bessel":n_bessel, \
                               "at":at } ]
                at      += L
            else:
                sys.exit( "[ERROR] undefined keyword :: {} ".format( words[1] ) )

    L_tot  = at
    print()
    print( f" -- all of the {elnum} elements were loaded...   -- " )
    print( f" --    total length of the beam line == {L_tot:.8} -- " )
    print()
                
    # ------------------------------------------------- #
    # --- [3] convert into mad-x sequence           --- #
    # ------------------------------------------------- #
    contents  = ""
    contents += "{0}: sequence, L={1:.8}, refer=entry;\n".format( seq_tag, L_tot )
    for ik,elem in enumerate(seq):
        if   ( elem["type"].lower() == "quadrupole" ):
            contents += "  {0}: quadrupole, L={1:.8}, K1={2:.8}, at={3:.8};\n"\
                .format( elem["tag"], elem["L"], elem["K1"], elem["at"] )
        elif ( elem["type"].lower() == "rfcavity"   ):
            contents += "  {0}: RFCavity, L={1:.8}, volt={2:.8}, lag={3:.8}, freq={4:.4}, harmon={5}, n_bessel={6}, at={7:.8};\n".format( elem["tag"], elem["L"], elem["volt"], elem["lag"], elem["freq"], elem["harmon"], elem["n_bessel"], elem["at"] )
        elif ( elem["type"].lower() == "drift"   ):
            contents += "  {0}: drift, L={1:.8}, at={2:.8};\n"\
                .format( elem["tag"], elem["L"], elem["at"] )
    contents += "endsequence;"
    with open( seqFile, "w" ) as f:
        f.write( contents )

    # ------------------------------------------------- #
    # --- [4] set ptc_observe points                --- #
    # ------------------------------------------------- #
    contents = ""
    for ik,elem in enumerate(seq):
        contents += "ptc_observe, place={};\n".format( elem["tag"] )
    with open( obsFile, "w" ) as f:
        f.write( contents )
    
            
# ========================================================= #
# ===   Execution of Pragram                            === #
# ========================================================= #

if ( __name__=="__main__" ):
    translate__track2madx()

