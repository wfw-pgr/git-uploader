############################
track / madx 比較 (1) (QM)
############################

コード
===========

madx
-----------

.. literalinclude:: results/qm-check/1a-deuteron.seq



track
-----------

.. literalinclude:: results/qm-check/sclinac.dat


                    
比較
===========

.. image:: results/qm-check/compare__madx_track.png
           :width:  500px

                    
* 体系は ４極電磁石とドリフトのみ
* よく一致しているので、変換コードに間違いはなさそう．

  
